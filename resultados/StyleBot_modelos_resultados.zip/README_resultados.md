# Resultados Fashion-MNIST

## Modelo elegido por validación
Regresión logística (HOG + Hu)

## División de datos
- Entrenamiento: 48,000 imágenes.
- Validación: 12,000 imágenes.
- Prueba: 10,000 imágenes.
- Semilla: 42.

## Modelos comparados
- Regresión logística.
- SVM lineal.
- Random Forest.
- Regresión logística con HOG y momentos de Hu.

Se compararon píxeles crudos y PCA. Los hiperparámetros
se ajustaron con validación cruzada estratificada.

## Mejor resultado de prueba
- Candidato: Regresión logística (HOG + Hu)
- Accuracy: 0.8840
- Precision ponderada: 0.8837
- Recall ponderado: 0.8840
- F1 ponderado: 0.8838

## Fuentes
- https://www.tensorflow.org/api_docs/python/tf/keras/datasets/fashion_mnist/load_data
- https://scikit-learn.org/stable/
- https://scikit-image.org/docs/stable/
